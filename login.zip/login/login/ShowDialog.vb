﻿
Class ShowDialog

    Property Filter As String

    Function ShowDialog() As DialogResult
        Throw New NotImplementedException
    End Function

    Function FileName() As Object
        Throw New NotImplementedException
    End Function

    Function FromFile(p1 As Object) As Image
        Throw New NotImplementedException
    End Function

End Class
