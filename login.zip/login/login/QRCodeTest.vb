﻿Imports MySql.Data.MySqlClient
Public Class QRCodeTest
    Dim connection As New MySqlConnection("datasource=localhost;port=3306;username=root;password=;database=qrcode")
    Dim dr As MySqlDataReader

    Private Sub QRCodeTest_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ClearButton_Click(sender As Object, e As EventArgs) Handles ClearButton.Click

        QRcodeinfoTextBox.Clear()

    End Sub

    Private Sub QRcodeinfoTextBox_TextChanged(sender As Object, e As EventArgs) Handles QRcodeinfoTextBox.TextChanged

    End Sub

    Private Sub savebutton_Click(sender As Object, e As EventArgs) Handles savebutton.Click
        Try


            Dim command As New MySqlCommand("SELECT `QRcode_info`,`img`,`Time` FROM `qrcode_info` WHERE `QRcode_info`=@QRcode_info", connection)

            command.Parameters.Add("@qrcode_info", MySqlDbType.VarChar).Value = QRcodeinfoTextBox.Text




        Dim adapter As New MySqlDataAdapter(command)
        Dim table As New DataTable()

        adapter.Fill(table)


        If table.Rows.Count = 0 Then
                QRCodeForm.Hide()
                Dim result As Integer = MessageBox.Show("QRcode is Not Tested. You Need To Create New QR Code First", " ", MessageBoxButtons.OKCancel)
                If result = DialogResult.OK Then
                    QRCodeForm.Show()
                    Me.Close()
                Else : result = DialogResult.Cancel

                End If
                

        Else
                QRCodeForm.Hide()
                MessageBox.Show("QRcode QR Code is Already Tested")
                Dim result As Integer = MessageBox.Show("Do You Want To Create New QR Code Click on Ok Button", "", MessageBoxButtons.OKCancel)
                If result = DialogResult.OK Then
                    QRCodeForm.Show()
                    Me.Close()

                End If
                'dr = command.ExecuteReader()

                'PictureBox1.ImageLocation = dr.GetString(1)
                'TestLabel.Text = dr.GetString(2)
                'MessageBox.Show(dr.GetValue(1) + dr.GetValue(2))


            End If

        Catch ex As Exception

        End Try


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        QRCodeForm.Show()
        Me.Hide()
    End Sub
End Class