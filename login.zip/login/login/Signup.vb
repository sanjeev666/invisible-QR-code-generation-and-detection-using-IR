﻿Imports MySql.Data.MySqlClient
Public Class Signup
    Dim connection As New MySqlConnection("datasource=localhost;port=3306;username=root;password=;database=qrcode")

    Private Sub ButtonSignup_Click(sender As Object, e As EventArgs) Handles ButtonSignup.Click
        If TextBoxpassword.Text.Equals(TextBoxPassword2.Text) Then
            Try
                connection.Open()
                Dim command As New MySqlCommand("insert into `login` values('" & TextBoxusername.Text & "','" & TextBoxpassword.Text & "')", connection)
                command.ExecuteReader()
                MessageBox.Show("Signup Successfull")
            Catch ex As Exception

            End Try
            
        End If
       
    End Sub

    Private Sub TextBoxPassword2_TextChanged(sender As Object, e As EventArgs) Handles TextBoxPassword2.TextChanged

    End Sub

    Private Sub Buttoncancel_Click(sender As Object, e As EventArgs) Handles Buttoncancel.Click
        LoginForm.Show()
        Me.Close()

    End Sub
End Class