public class QRCodeEncoder
{
    // Fields
    internal static string DATA_PATH = "qrcode_data";
    internal static string QRCODE_DATA_PATH = string.Empty;
    internal ERROR_CORRECTION qrcodeErrorCorrect = ERROR_CORRECTION.M;
    internal ENCODE_MODE qrcodeEncodeMode = ENCODE_MODE.BYTE;
    internal int qrcodeVersion = 7;
    internal int qrcodeStructureappendN = 0;
    internal int qrcodeStructureappendM = 0;
    internal int qrcodeStructureappendParity = 0;
    internal Color qrCodeBackgroundColor = Color.White;
    internal Color qrCodeForegroundColor = Color.Black;
    internal int qrCodeScale = 4;
    internal string qrcodeStructureappendOriginaldata = "";

    // Methods
    private static sbyte[] calculateByteArrayBits(sbyte[] xa, sbyte[] xb, string ind)
    {
        sbyte[] numArray2;
        sbyte[] numArray3;
        if (xa.Length > xb.Length)
        {
		  
            numArray2 = new sbyte[xa.Length];
            xa.CopyTo(numArray2, 0);
            numArray3 = new sbyte[xb.Length];
            xb.CopyTo(numArray3, 0);
        }
        else
        {
            numArray2 = new sbyte[xb.Length];
            xb.CopyTo(numArray2, 0);
            numArray3 = new sbyte[xa.Length];
            xa.CopyTo(numArray3, 0);
        }
        int length = numArray2.Length;
        int num2 = numArray3.Length;
        sbyte[] numArray = new sbyte[length];
        for (int i = 0; i < length; i++)
        {
            if (i < num2)
            {
                numArray[i] = !ReferenceEquals(ind, "xor") ? ((sbyte) (numArray2[i] | numArray3[i])) : ((sbyte) (numArray2[i] ^ numArray3[i]));
            }
            else
            {
                numArray[i] = numArray2[i];
            }
        }
        return numArray;
    }

    private static sbyte[] calculateRSECC(sbyte[] codewords, sbyte rsEccCodewords, sbyte[] rsBlockOrder, int maxDataCodewords, int maxCodewords)
    {
        sbyte[][] numArray = new sbyte[0x100][];
        int index = 0;
        while (true)
        {
            bool flag = index < 0x100;
            if (!flag)
            {
                try
                {
                    Stream embeddedFile = GetEmbeddedFile(DATA_PATH + ".rsc" + rsEccCodewords.ToString() + ".dat");
                    BufferedStream sourceStream = new BufferedStream(embeddedFile);
                    index = 0;
                    while (true)
                    {
                        flag = index < 0x100;
                        if (!flag)
                        {
                            sourceStream.Close();
                            embeddedFile.Close();
                            break;
                        }
                        SystemUtils.ReadInput(sourceStream, numArray[index], 0, numArray[index].Length);
                        index++;
                    }
                }
                catch (Exception exception1)
                {
                    SystemUtils.WriteStackTrace(exception1, Console.Error);
                }
                int num2 = 0;
                int num3 = 0;
                int num4 = 0;
                sbyte[][] numArray2 = new sbyte[rsBlockOrder.Length][];
                sbyte[] destinationArray = new sbyte[maxCodewords];
                Array.Copy(codewords, 0, destinationArray, 0, codewords.Length);
                num2 = 0;
                while (true)
                {
                    flag = num2 < rsBlockOrder.Length;
                    if (!flag)
                    {
                        num2 = 0;
                        while (true)
                        {
                            flag = num2 < maxDataCodewords;
                            if (!flag)
                            {
                                num4 = 0;
                                while (num4 < rsBlockOrder.Length)
                                {
                                    sbyte[] array = new sbyte[numArray2[num4].Length];
                                    numArray2[num4].CopyTo(array, 0);
                                    int num5 = rsBlockOrder[num4] & 0xff;
                                    num3 = num5 - rsEccCodewords;
                                    while (true)
                                    {
                                        flag = num3 > 0;
                                        if (!flag)
                                        {
                                            Array.Copy(array, 0, destinationArray, codewords.Length + (num4 * rsEccCodewords), (byte) rsEccCodewords);
                                            num4++;
                                            break;
                                        }
                                        sbyte num7 = array[0];
                                        if (num7 != 0)
                                        {
                                            sbyte[] numArray5 = new sbyte[array.Length - 1];
                                            Array.Copy(array, 1, numArray5, 0, array.Length - 1);
                                            array = calculateByteArrayBits(numArray5, numArray[num7 & 0xff], "xor");
                                        }
                                        else
                                        {
                                            sbyte[] numArray7;
                                            if (rsEccCodewords < array.Length)
                                            {
                                                numArray7 = new sbyte[array.Length - 1];
                                                Array.Copy(array, 1, numArray7, 0, array.Length - 1);
                                                numArray7.CopyTo(new sbyte[numArray7.Length], 0);
                                            }
                                            else
                                            {
                                                numArray7 = new sbyte[rsEccCodewords];
                                                Array.Copy(array, 1, numArray7, 0, array.Length - 1);
                                                numArray7[rsEccCodewords - 1] = 0;
                                                numArray7.CopyTo(new sbyte[numArray7.Length], 0);
                                            }
                                        }
                                        num3--;
                                    }
                                }
                                return destinationArray;
                            }
                            numArray2[num4][num3] = codewords[num2];
                            if ((num3 + 1) >= ((rsBlockOrder[num4] & 0xff) - rsEccCodewords))
                            {
                                num3 = 0;
                                num4++;
                            }
                            num2++;
                        }
                    }
                    numArray2[num2] = new sbyte[(rsBlockOrder[num2] & 0xff) - rsEccCodewords];
                    num2++;
                }
            }
            numArray[index] = new sbyte[rsEccCodewords];
            index++;
        }
    }

    public virtual bool[][] calQrcode(byte[] qrcodeData)
    {
        bool[][] flagArray3;
        int index = 0;
        int length = qrcodeData.Length;
        int[] data = new int[length + 0x20];
        sbyte[] bits = new sbyte[length + 0x20];
        if (length <= 0)
        {
            flagArray3 = new bool[][] { new bool[1] };
        }
        else
        {
            int[] numArray3;
            int num3;
            int num4;
            bool flag;
            if (this.qrcodeStructureappendN > 1)
            {
                data[0] = 3;
                bits[0] = 4;
                data[1] = this.qrcodeStructureappendM - 1;
                bits[1] = 4;
                data[2] = this.qrcodeStructureappendN - 1;
                bits[2] = 4;
                data[3] = this.qrcodeStructureappendParity;
                bits[3] = 8;
                index = 4;
            }
            bits[index] = 4;
            switch (this.qrcodeEncodeMode)
            {
                case ENCODE_MODE.ALPHA_NUMERIC:
                    numArray3 = new int[] { 
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2,
                        2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 4, 4, 4, 4, 4,
                        4, 4, 4, 4, 4, 4, 4, 4, 4
                    };
                    data[index] = 2;
                    index++;
                    data[index] = length;
                    bits[index] = 9;
                    num3 = index;
                    index++;
                    num4 = 0;
                    while (true)
                    {
                        flag = num4 < length;
                        if (!flag)
                        {
                            index++;
                            break;
                        }
                        char ch = (char) qrcodeData[num4];
                        sbyte num5 = 0;
                        if ((ch >= '0') && (ch < ':'))
                        {
                            num5 = (sbyte) (ch - '0');
                        }
                        else if ((ch >= 'A') && (ch < '['))
                        {
                            num5 = (sbyte) (ch - '7');
                        }
                        else
                        {
                            if (ch == ' ')
                            {
                                num5 = 0x24;
                            }
                            if (ch == '$')
                            {
                                num5 = 0x25;
                            }
                            if (ch == '%')
                            {
                                num5 = 0x26;
                            }
                            if (ch == '*')
                            {
                                num5 = 0x27;
                            }
                            if (ch == '+')
                            {
                                num5 = 40;
                            }
                            if (ch == '-')
                            {
                                num5 = 0x29;
                            }
                            if (ch == '.')
                            {
                                num5 = 0x2a;
                            }
                            if (ch == '/')
                            {
                                num5 = 0x2b;
                            }
                            if (ch == ':')
                            {
                                num5 = 0x2c;
                            }
                        }
                        if ((num4 % 2) == 0)
                        {
                            data[index] = num5;
                            bits[index] = 6;
                        }
                        else
                        {
                            data[index] = (data[index] * 0x2d) + num5;
                            bits[index] = 11;
                            if (num4 < (length - 1))
                            {
                                index++;
                            }
                        }
                        num4++;
                    }
                    break;

                case ENCODE_MODE.NUMERIC:
                    numArray3 = new int[] { 
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2,
                        2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 4, 4, 4, 4, 4,
                        4, 4, 4, 4, 4, 4, 4, 4, 4
                    };
                    data[index] = 1;
                    index++;
                    data[index] = length;
                    bits[index] = 10;
                    num3 = index;
                    index++;
                    num4 = 0;
                    while (true)
                    {
                        flag = num4 < length;
                        if (!flag)
                        {
                            index++;
                            break;
                        }
                        if ((num4 % 3) == 0)
                        {
                            data[index] = qrcodeData[num4] - 0x30;
                            bits[index] = 4;
                        }
                        else
                        {
                            data[index] = (data[index] * 10) + (qrcodeData[num4] - 0x30);
                            if ((num4 % 3) == 1)
                            {
                                bits[index] = 7;
                            }
                            else
                            {
                                bits[index] = 10;
                                if (num4 < (length - 1))
                                {
                                    index++;
                                }
                            }
                        }
                        num4++;
                    }
                    break;

                default:
                    numArray3 = new int[] { 
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 8, 8, 8, 8, 8,
                        8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8,
                        8, 8, 8, 8, 8, 8, 8, 8, 8
                    };
                    data[index] = 4;
                    index++;
                    data[index] = length;
                    bits[index] = 8;
                    num3 = index;
                    index++;
                    num4 = 0;
                    while (true)
                    {
                        flag = num4 < length;
                        if (!flag)
                        {
                            index += length;
                            break;
                        }
                        data[num4 + index] = qrcodeData[num4] & 0xff;
                        bits[num4 + index] = 8;
                        num4++;
                    }
                    break;
            }
            int num6 = 0;
            num4 = 0;
            while (true)
            {
                flag = num4 < index;
                if (!flag)
                {
                    int num7;
                    Stream embeddedFile;
                    BufferedStream stream2;
                    string[] strArray2;
                    switch (this.qrcodeErrorCorrect)
                    {
                        case ERROR_CORRECTION.L:
                            num7 = 1;
                            break;

                        case ERROR_CORRECTION.Q:
                            num7 = 3;
                            break;

                        case ERROR_CORRECTION.H:
                            num7 = 2;
                            break;

                        default:
                            num7 = 0;
                            break;
                    }
                    int[][] numArray4 = new int[][] { new int[] { 
                        0, 0x80, 0xe0, 0x160, 0x200, 0x2b0, 0x360, 0x3e0, 0x4d0, 0x5b0, 0x6c0, 0x7f0, 0x910, 0xa70, 0xb68, 0xcf8,
                        0xe28, 0xfd8, 0x1198, 0x1398, 0x14e8, 0x1650, 0x1870, 0x1ae0, 0x1c90, 0x1f40, 0x2130, 0x2340, 0x2548, 0x2798, 0x2ae8, 0x2d78,
                        0x3028, 0x32f8, 0x35e8, 0x38a0, 0x3bd0, 0x3e40, 0x41b0, 0x4540, 0x48f0
                    }, new int[] { 
                        0, 0x98, 0x110, 440, 640, 0x360, 0x440, 0x4e0, 0x610, 0x740, 0x890, 0xa20, 0xb90, 0xd60, 0xe68, 0x1058,
                        0x1268, 0x1438, 0x1688, 0x18d8, 0x1ae8, 0x1d20, 0x1f70, 0x2230, 0x24b0, 0x27e0, 0x2ad0, 0x2de0, 0x2fd8, 0x32f8, 0x3638, 0x3998,
                        0x3d18, 0x40b8, 0x4478, 0x4810, 0x4c10, 0x5030, 0x5470, 0x57e0, 0x5c60
                    }, new int[] { 
                        0, 0x48, 0x80, 0xd0, 0x120, 0x170, 480, 0x210, 0x2b0, 800, 0x3d0, 0x460, 0x4f0, 0x5a0, 0x628, 0x6f8,
                        0x7e8, 0x8d8, 0x9c8, 0xaa8, 0xc08, 0xcb0, 0xdd0, 0xe80, 0x1010, 0x10d0, 0x12a0, 0x13a0, 0x14a8, 0x15e8, 0x1748, 0x18c8,
                        0x1a68, 0x1c28, 0x1e08, 0x1ed0, 0x20f0, 0x2240, 0x23b0, 0x2630, 0x27e0
                    }, new int[] { 
                        0, 0x68, 0xb0, 0x110, 0x180, 0x1f0, 0x260, 0x2c0, 880, 0x420, 0x4d0, 0x5a0, 0x670, 0x7a0, 0x828, 0x938,
                        0xa28, 0xb78, 0xc68, 0xde8, 0xf28, 0x1000, 0x11c0, 0x1330, 0x14c0, 0x1670, 0x1790, 0x1940, 0x1b38, 0x1c78, 0x1ec8, 0x2048,
                        0x22d8, 0x2498, 0x2678, 0x2830, 0x2a50, 0x2c90, 0x2ef0, 0x3170, 0x3410
                    } };
                    int num8 = 0;
                    if (this.qrcodeVersion != 0)
                    {
                        num8 = numArray4[num7][this.qrcodeVersion];
                    }
                    else
                    {
                        this.qrcodeVersion = 1;
                        num4 = 1;
                        while (true)
                        {
                            flag = num4 <= 40;
                            if (flag)
                            {
                                if (numArray4[num7][num4] < (num6 + numArray3[this.qrcodeVersion]))
                                {
                                    this.qrcodeVersion++;
                                    num4++;
                                    continue;
                                }
                                num8 = numArray4[num7][num4];
                            }
                            break;
                        }
                    }
                    num6 += numArray3[this.qrcodeVersion];
                    bits[num3] = (sbyte) (bits[num3] + numArray3[this.qrcodeVersion]);
                    int maxCodewords = new int[] { 
                        0, 0x1a, 0x2c, 70, 100, 0x86, 0xac, 0xc4, 0xf2, 0x124, 0x15a, 0x194, 0x1d2, 0x214, 0x245, 0x28f,
                        0x2dd, 0x32f, 0x385, 0x3df, 0x43d, 0x484, 0x4ea, 0x554, 0x5c2, 0x634, 0x6aa, 0x724, 0x781, 0x803, 0x889, 0x913,
                        0x9a1, 0xa33, 0xac9, 0xb3c, 0xbda, 0xc7c, 0xd22, 0xdcc, 0xe7a
                    }[this.qrcodeVersion];
                    int num10 = 0x11 + (this.qrcodeVersion << 2);
                    int[] numArray6 = new int[] { 
                        0, 0, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0, 0, 0, 3, 3,
                        3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 3, 3, 3, 3,
                        3, 3, 3, 0, 0, 0, 0, 0, 0
                    };
                    int num11 = numArray6[this.qrcodeVersion] + (maxCodewords << 3);
                    sbyte[] target = new sbyte[num11];
                    sbyte[] numArray8 = new sbyte[num11];
                    sbyte[] numArray9 = new sbyte[num11];
                    sbyte[] numArray10 = new sbyte[15];
                    sbyte[] numArray11 = new sbyte[15];
                    sbyte[] numArray12 = new sbyte[1];
                    sbyte[] numArray13 = new sbyte[0x80];
                    try
                    {
                        strArray2 = new string[] { DATA_PATH, ".qrv", Convert.ToString(this.qrcodeVersion), "_", Convert.ToString(num7), ".dat" };
                        string fileName = string.Concat(strArray2);
                        embeddedFile = GetEmbeddedFile(fileName);
                        stream2 = new BufferedStream(embeddedFile);
                        SystemUtils.ReadInput(stream2, target, 0, target.Length);
                        SystemUtils.ReadInput(stream2, numArray8, 0, numArray8.Length);
                        SystemUtils.ReadInput(stream2, numArray9, 0, numArray9.Length);
                        SystemUtils.ReadInput(stream2, numArray10, 0, numArray10.Length);
                        SystemUtils.ReadInput(stream2, numArray11, 0, numArray11.Length);
                        SystemUtils.ReadInput(stream2, numArray12, 0, numArray12.Length);
                        SystemUtils.ReadInput(stream2, numArray13, 0, numArray13.Length);
                        stream2.Close();
                        embeddedFile.Close();
                    }
                    catch (Exception exception1)
                    {
                        SystemUtils.WriteStackTrace(exception1, Console.Error);
                    }
                    sbyte num12 = 1;
                    sbyte num13 = 1;
                    while (true)
                    {
                        flag = num13 < 0x80;
                        if (flag)
                        {
                            if (numArray13[num13] != 0)
                            {
                                num13 = (sbyte) (num13 + 1);
                                continue;
                            }
                            num12 = num13;
                        }
                        sbyte[] destinationArray = new sbyte[num12];
                        Array.Copy(numArray13, 0, destinationArray, 0, (byte) num12);
                        sbyte[] numArray15 = new sbyte[] { 0, 1, 2, 3, 4, 5, 7, 8, 8, 8, 8, 8, 8, 8, 8 };
                        sbyte[] numArray16 = new sbyte[] { 8, 8, 8, 8, 8, 8, 8, 8, 7, 5, 4, 3, 2, 1, 0 };
                        int maxDataCodewords = num8 >> 3;
                        int num15 = (4 * this.qrcodeVersion) + 0x11;
                        sbyte[] numArray17 = new sbyte[(num15 * num15) + num15];
                        try
                        {
                            embeddedFile = GetEmbeddedFile(DATA_PATH + ".qrvfr" + Convert.ToString(this.qrcodeVersion) + ".dat");
                            stream2 = new BufferedStream(embeddedFile);
                            SystemUtils.ReadInput(stream2, numArray17, 0, numArray17.Length);
                            stream2.Close();
                            embeddedFile.Close();
                        }
                        catch (Exception exception2)
                        {
                            SystemUtils.WriteStackTrace(exception2, Console.Error);
                        }
                        if (num6 <= (num8 - 4))
                        {
                            data[index] = 0;
                            bits[index] = 4;
                        }
                        else if (num6 < num8)
                        {
                            data[index] = 0;
                            bits[index] = (sbyte) (num8 - num6);
                        }
                        else if (num6 > num8)
                        {
                            Console.Out.WriteLine("overflow");
                        }
                        sbyte[] numArray19 = calculateRSECC(divideDataBy8Bits(data, bits, maxDataCodewords), numArray12[0], destinationArray, maxDataCodewords, maxCodewords);
                        sbyte[][] matrixContent = new sbyte[num15][];
                        int num17 = 0;
                        while (true)
                        {
                            flag = num17 < num15;
                            if (!flag)
                            {
                                num4 = 0;
                                while (true)
                                {
                                    int num18;
                                    if (num4 >= num15)
                                    {
                                        num4 = 0;
                                        while (true)
                                        {
                                            if (num4 >= maxCodewords)
                                            {
                                                int num21 = numArray6[this.qrcodeVersion];
                                                while (true)
                                                {
                                                    flag = num21 > 0;
                                                    if (!flag)
                                                    {
                                                        sbyte num23 = selectMask(matrixContent, numArray6[this.qrcodeVersion] + (maxCodewords * 8));
                                                        sbyte num24 = (sbyte) (1 << (num23 & 0x1f));
                                                        sbyte num25 = (sbyte) ((num7 << 3) | num23);
                                                        strArray2 = new string[] { "101010000010010", "101000100100101", "101111001111100", "101101101001011", "100010111111001", "100000011001110", "100111110010111", "100101010100000", "111011111000100" };
                                                        strArray2[9] = "111001011110011";
                                                        strArray2[10] = "111110110101010";
                                                        strArray2[11] = "111100010011101";
                                                        strArray2[12] = "110011000101111";
                                                        strArray2[13] = "110001100011000";
                                                        strArray2[14] = "110110001000001";
                                                        strArray2[15] = "110100101110110";
                                                        strArray2[0x10] = "001011010001001";
                                                        strArray2[0x11] = "001001110111110";
                                                        strArray2[0x12] = "001110011100111";
                                                        strArray2[0x13] = "001100111010000";
                                                        strArray2[20] = "000011101100010";
                                                        strArray2[0x15] = "000001001010101";
                                                        strArray2[0x16] = "000110100001100";
                                                        strArray2[0x17] = "000100000111011";
                                                        strArray2[0x18] = "011010101011111";
                                                        strArray2[0x19] = "011000001101000";
                                                        strArray2[0x1a] = "011111100110001";
                                                        strArray2[0x1b] = "011101000000110";
                                                        strArray2[0x1c] = "010010010110100";
                                                        strArray2[0x1d] = "010000110000011";
                                                        strArray2[30] = "010111011011010";
                                                        strArray2[0x1f] = "010101111101101";
                                                        string[] strArray = strArray2;
                                                        num4 = 0;
                                                        while (true)
                                                        {
                                                            flag = num4 < 15;
                                                            if (!flag)
                                                            {
                                                                bool[][] flagArray2 = new bool[num15][];
                                                                int num27 = 0;
                                                                while (true)
                                                                {
                                                                    flag = num27 < num15;
                                                                    if (!flag)
                                                                    {
                                                                        int num28 = 0;
                                                                        num4 = 0;
                                                                        while (true)
                                                                        {
                                                                            if (num4 >= num15)
                                                                            {
                                                                                flagArray3 = flagArray2;
                                                                                break;
                                                                            }
                                                                            num18 = 0;
                                                                            while (true)
                                                                            {
                                                                                flag = num18 < num15;
                                                                                if (!flag)
                                                                                {
                                                                                    num28++;
                                                                                    num4++;
                                                                                    break;
                                                                                }
                                                                                flagArray2[num18][num4] = ((matrixContent[num18][num4] & num24) != 0) || (numArray17[num28] == 0x31);
                                                                                num28++;
                                                                                num18++;
                                                                            }
                                                                        }
                                                                        break;
                                                                    }
                                                                    flagArray2[num27] = new bool[num15];
                                                                    num27++;
                                                                }
                                                                break;
                                                            }
                                                            sbyte num26 = sbyte.Parse(strArray[num25].Substring(num4, (num4 + 1) - num4));
                                                            matrixContent[numArray15[num4] & 0xff][numArray16[num4] & 0xff] = (sbyte) (num26 * 0xff);
                                                            matrixContent[numArray10[num4] & 0xff][numArray11[num4] & 0xff] = (sbyte) (num26 * 0xff);
                                                            num4++;
                                                        }
                                                        break;
                                                    }
                                                    int num22 = (num21 + (maxCodewords * 8)) - 1;
                                                    matrixContent[target[num22] & 0xff][numArray8[num22] & 0xff] = (sbyte) (0xff ^ numArray9[num22]);
                                                    num21--;
                                                }
                                                break;
                                            }
                                            sbyte num19 = numArray19[num4];
                                            num18 = 7;
                                            while (true)
                                            {
                                                flag = num18 >= 0;
                                                if (!flag)
                                                {
                                                    num4++;
                                                    break;
                                                }
                                                int num20 = (num4 * 8) + num18;
                                                matrixContent[target[num20] & 0xff][numArray8[num20] & 0xff] = (sbyte) ((0xff * (num19 & 1)) ^ numArray9[num20]);
                                                num19 = (sbyte) SystemUtils.URShift((int) (num19 & 0xff), 1);
                                                num18--;
                                            }
                                        }
                                        break;
                                    }
                                    num18 = 0;
                                    while (true)
                                    {
                                        flag = num18 < num15;
                                        if (!flag)
                                        {
                                            num4++;
                                            break;
                                        }
                                        matrixContent[num18][num4] = 0;
                                        num18++;
                                    }
                                }
                                break;
                            }
                            matrixContent[num17] = new sbyte[num15];
                            num17++;
                        }
                        break;
                    }
                    break;
                }
                num6 += bits[num4];
                num4++;
            }
        }
        return flagArray3;
    }

    public virtual int calStructureappendParity(sbyte[] originaldata)
    {
        int index = 0;
        int num3 = 0;
        int length = originaldata.Length;
        if (length <= 1)
        {
            num3 = -1;
        }
        else
        {
            num3 = 0;
            while (true)
            {
                if (index >= length)
                {
                    break;
                }
                num3 ^= originaldata[index] & 0xff;
                index++;
            }
        }
        return num3;
    }

    private static sbyte[] divideDataBy8Bits(int[] data, sbyte[] bits, int maxDataCodewords)
    {
        int length = bits.Length;
        int index = 0;
        int num4 = 8;
        int num5 = 0;
        if (length != data.Length)
        {
        }
        int num8 = 0;
        while (true)
        {
            bool flag2 = num8 < length;
            if (!flag2)
            {
                int num2 = ((num5 - 1) / 8) + 1;
                sbyte[] numArray = new sbyte[maxDataCodewords];
                num8 = 0;
                while (true)
                {
                    flag2 = num8 < num2;
                    if (!flag2)
                    {
                        num8 = 0;
                        while (true)
                        {
                            bool flag;
                            flag2 = num8 < length;
                            if (flag2)
                            {
                                int num6 = data[num8];
                                int num7 = bits[num8];
                                flag = true;
                                if (num7 != 0)
                                {
                                    while (true)
                                    {
                                        flag2 = flag;
                                        if (!flag2)
                                        {
                                            num8++;
                                            break;
                                        }
                                        if (num4 > num7)
                                        {
                                            numArray[index] = (sbyte) ((numArray[index] << (num7 & 0x1f)) | num6);
                                            num4 -= num7;
                                            flag = false;
                                            continue;
                                        }
                                        num7 -= num4;
                                        numArray[index] = (sbyte) ((numArray[index] << (num4 & 0x1f)) | (num6 >> (num7 & 0x1f)));
                                        if (num7 == 0)
                                        {
                                            flag = false;
                                        }
                                        else
                                        {
                                            num6 &= (1 << (num7 & 0x1f)) - 1;
                                            flag = true;
                                        }
                                        index++;
                                        num4 = 8;
                                    }
                                    continue;
                                }
                            }
                            if (num4 != 8)
                            {
                                numArray[index] = (sbyte) (numArray[index] << (num4 & 0x1f));
                            }
                            else
                            {
                                index--;
                            }
                            if (index < (maxDataCodewords - 1))
                            {
                                flag = true;
                                while (true)
                                {
                                    flag2 = index < (maxDataCodewords - 1);
                                    if (!flag2)
                                    {
                                        break;
                                    }
                                    index++;
                                    numArray[index] = !flag ? 0x11 : -20;
                                    flag = !flag;
                                }
                            }
                            return numArray;
                        }
                    }
                    numArray[num8] = 0;
                    num8++;
                }
            }
            num5 += bits[num8];
            num8++;
        }
    }

    public virtual Bitmap Encode(string content) => 
        (!QRCodeUtility.IsUniCode(content) ? this.Encode(content, Encoding.ASCII) : this.Encode(content, Encoding.Unicode));

    public virtual Bitmap Encode(string content, Encoding encoding)
    {
        bool[][] flagArray = this.calQrcode(encoding.GetBytes(content));
        SolidBrush brush = new SolidBrush(this.qrCodeBackgroundColor);
        Bitmap image = new Bitmap((flagArray.Length * this.qrCodeScale) + 1, (flagArray.Length * this.qrCodeScale) + 1);
        Graphics graphics = Graphics.FromImage(image);
        graphics.FillRectangle(brush, new Rectangle(0, 0, image.Width, image.Height));
        brush.Color = this.qrCodeForegroundColor;
        int index = 0;
        while (index < flagArray.Length)
        {
            int num2 = 0;
            while (true)
            {
                if (num2 >= flagArray.Length)
                {
                    index++;
                    break;
                }
                if (flagArray[num2][index])
                {
                    graphics.FillRectangle(brush, num2 * this.qrCodeScale, index * this.qrCodeScale, this.qrCodeScale, this.qrCodeScale);
                }
                num2++;
            }
        }
        return image;
    }

    internal static Stream GetEmbeddedFile(string fileName)
    {
        Stream stream2;
        string name = typeof(QRCodeEncoder).Assembly.GetName().Name;
        try
        {
            Stream manifestResourceStream = Assembly.Load(name).GetManifestResourceStream(name + "." + fileName);
            if (ReferenceEquals(manifestResourceStream, null))
            {
                string[] strArray = new string[] { "Could not locate embedded resource '", fileName, "' in assembly '", name, "'" };
                throw new Exception(string.Concat(strArray));
            }
            stream2 = manifestResourceStream;
        }
        catch (Exception exception)
        {
            throw new Exception(name + ": " + exception.Message);
        }
        return stream2;
    }

    internal static Bitmap GetEmbeddedImage(string fileName) => 
        new Bitmap(GetEmbeddedFile(fileName));

    internal static XmlDocument GetEmbeddedXml(string fileName)
    {
        XmlDocument document = new XmlDocument();
        document.Load(new XmlTextReader(GetEmbeddedFile(fileName)));
        return document;
    }

    private static unsafe sbyte selectMask(sbyte[][] matrixContent, int maxCodewordsBitWithRemain)
    {
        int length = matrixContent.Length;
        int[] numArray = new int[8];
        int[] numArray2 = new int[8];
        int[] numArray3 = new int[8];
        int[] numArray4 = new int[8];
        int num2 = 0;
        int num3 = 0;
        int[] numArray5 = new int[8];
        int index = 0;
        while (true)
        {
            int num6;
            bool flag = index < length;
            if (!flag)
            {
                int num7 = 0;
                sbyte num8 = 0;
                int[] numArray8 = new int[] { 
                    90, 80, 70, 60, 50, 40, 30, 20, 10, 0, 0, 10, 20, 30, 40, 50,
                    60, 70, 80, 90, 90
                };
                num6 = 0;
                while (true)
                {
                    flag = num6 < 8;
                    if (!flag)
                    {
                        return num8;
                    }
                    numArray4[num6] = numArray8[(20 * numArray5[num6]) / maxCodewordsBitWithRemain];
                    int num9 = ((numArray[num6] + numArray2[num6]) + numArray3[num6]) + numArray4[num6];
                    if ((num9 < num7) || (num6 == 0))
                    {
                        num8 = (sbyte) num6;
                        num7 = num9;
                    }
                    num6++;
                }
            }
            int[] numArray6 = new int[8];
            int[] numArray7 = new int[8];
            bool[] flagArray = new bool[8];
            bool[] flagArray2 = new bool[8];
            int num5 = 0;
            while (true)
            {
                if (num5 >= length)
                {
                    index++;
                    break;
                }
                if ((num5 > 0) && (index > 0))
                {
                    num2 = (((matrixContent[num5][index] & matrixContent[num5 - 1][index]) & matrixContent[num5][index - 1]) & matrixContent[num5 - 1][index - 1]) & 0xff;
                    num3 = (((matrixContent[num5][index] & 0xff) | (matrixContent[num5 - 1][index] & 0xff)) | (matrixContent[num5][index - 1] & 0xff)) | (matrixContent[num5 - 1][index - 1] & 0xff);
                }
                num6 = 0;
                while (true)
                {
                    flag = num6 < 8;
                    if (!flag)
                    {
                        num5++;
                        break;
                    }
                    numArray6[num6] = ((numArray6[num6] & 0x3f) << 1) | (SystemUtils.URShift((int) (matrixContent[num5][index] & 0xff), num6) & 1);
                    numArray7[num6] = ((numArray7[num6] & 0x3f) << 1) | (SystemUtils.URShift((int) (matrixContent[index][num5] & 0xff), num6) & 1);
                    if ((matrixContent[num5][index] & (1 << (num6 & 0x1f))) != 0)
                    {
                        int* numPtr1 = (int*) ref numArray5[num6];
                        numPtr1[0]++;
                    }
                    if (numArray6[num6] == 0x5d)
                    {
                        int* numPtr2 = (int*) ref numArray3[num6];
                        numPtr2[0] += 40;
                    }
                    if (numArray7[num6] == 0x5d)
                    {
                        int* numPtr3 = (int*) ref numArray3[num6];
                        numPtr3[0] += 40;
                    }
                    if ((num5 > 0) && (index > 0))
                    {
                        if (((num2 & 1) != 0) || ((num3 & 1) == 0))
                        {
                            int* numPtr4 = (int*) ref numArray2[num6];
                            numPtr4[0] += 3;
                        }
                        num2 = num2 >> 1;
                        num3 = num3 >> 1;
                    }
                    if (((numArray6[num6] & 0x1f) != 0) && ((numArray6[num6] & 0x1f) != 0x1f))
                    {
                        flagArray[num6] = false;
                    }
                    else if (num5 > 3)
                    {
                        if (flagArray[num6])
                        {
                            int* numPtr5 = (int*) ref numArray[num6];
                            numPtr5[0]++;
                        }
                        else
                        {
                            int* numPtr6 = (int*) ref numArray[num6];
                            numPtr6[0] += 3;
                            flagArray[num6] = true;
                        }
                    }
                    if (((numArray7[num6] & 0x1f) != 0) && ((numArray7[num6] & 0x1f) != 0x1f))
                    {
                        flagArray2[num6] = false;
                    }
                    else if (num5 > 3)
                    {
                        if (flagArray2[num6])
                        {
                            int* numPtr7 = (int*) ref numArray[num6];
                            numPtr7[0]++;
                        }
                        else
                        {
                            int* numPtr8 = (int*) ref numArray[num6];
                            numPtr8[0] += 3;
                            flagArray2[num6] = true;
                        }
                    }
                    num6++;
                }
            }
        }
    }

    public virtual void setStructureappend(int m, int n, int p)
    {
        int num1;
        if (((n <= 1) || ((n > 0x10) || ((m <= 0) || (m > 0x10)))) || (p < 0))
        {
            num1 = 1;
        }
        else
        {
            num1 = (int) (p > 0xff);
        }
        if (num1 == 0)
        {
            this.qrcodeStructureappendM = m;
            this.qrcodeStructureappendN = n;
            this.qrcodeStructureappendParity = p;
        }
    }

    // Properties
    public virtual ERROR_CORRECTION QRCodeErrorCorrect
    {
        get => 
            this.qrcodeErrorCorrect;
        set => 
            (this.qrcodeErrorCorrect = value);
    }

    public virtual int QRCodeVersion
    {
        get => 
            this.qrcodeVersion;
        set
        {
            if ((value >= 0) && (value <= 40))
            {
                this.qrcodeVersion = value;
            }
        }
    }

    public virtual ENCODE_MODE QRCodeEncodeMode
    {
        get => 
            this.qrcodeEncodeMode;
        set => 
            (this.qrcodeEncodeMode = value);
    }

    public virtual int QRCodeScale
    {
        get => 
            this.qrCodeScale;
        set => 
            (this.qrCodeScale = value);
    }

    public virtual Color QRCodeBackgroundColor
    {
        get => 
            this.qrCodeBackgroundColor;
        set => 
            (this.qrCodeBackgroundColor = value);
    }

    public virtual Color QRCodeForegroundColor
    {
        get => 
            this.qrCodeForegroundColor;
        set => 
            (this.qrCodeForegroundColor = value);
    }

    // Nested Types
    public enum ENCODE_MODE
    {
        ALPHA_NUMERIC,
        NUMERIC,
        BYTE
    }

    public enum ERROR_CORRECTION
    {
        L,
        M,
        Q,
        H
    }
}

 

 
