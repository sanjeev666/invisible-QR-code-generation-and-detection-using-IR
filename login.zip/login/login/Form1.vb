﻿Imports MySql.Data.MySqlClient
Imports System.IO
Public Class QRCodeForm
    Dim connection As New MySqlConnection("datasource=localhost;port=3306;username=root;password=;database=qrcode")
    Dim filepath As String
    Dim QR_Generator As New MessagingToolkit.QRCode.Codec.QRCodeEncoder
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
           
                Dim result As Integer = MessageBox.Show("Do you want to save QR Code Inforation in DB Please Click on OK Button", " ", MessageBoxButtons.OKCancel)
                If result = DialogResult.OK Then
                    'filepath = Path.GetFullPath(My.Application.Info.DirectoryPath + "\..") + "\Images\" + TextBox1.Text
                    filepath = AppDomain.CurrentDomain.BaseDirectory
                    filepath = filepath.Replace("\bin\Debug\", "\Images\")
                    filepath = filepath.Replace("\", "\\")
                filepath += TextBox1.Text + ".bmp"

                If Not PictureBox1.Image Is Nothing Then
                    Dim command As New MySqlCommand("insert into `qrcode_info`(`qrcode_info`,`img`) values ('" & TextBox1.Text & "','" & filepath & "')", connection)
                    Dim adapter As New MySqlDataAdapter(command)
                    Dim table As New DataTable()
                    adapter.Fill(table)
                    PictureBox1.Image.Save(filepath)
                Else
                    MessageBox.Show("Please generate QR Code first.")
                End If

            End If

            'command.Parameters.Add("@qri", MySqlDbType.VarChar).Value = TextBox1.Text




            'SaveFileDialog1.ShowDialog()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub SaveFileDialog1_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog1.FileOk
        Try

            Dim img As New Bitmap(PictureBox1.Image)
            img.Save(SaveFileDialog1.FileName)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            'Dim cmd As New MySqlCommand("insert into qrcode_info values() 
            PictureBox1.Image = QR_Generator.Encode(TextBox1.Text)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        TextBox1.Clear()
        PictureBox1.Image = Nothing
    End Sub

    Private Sub PictureBox1_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox1.Click

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

    End Sub

    Private Function QRcodeinfoTextBox() As Object
        Throw New NotImplementedException
    End Function

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        QRCodeTest.Show()
        Me.Close()
    End Sub
End Class
