﻿Imports MySql.Data.MySqlClient
Public Class LoginForm
    Dim connection As New MySqlConnection("datasource=localhost;port=3306;username=root;password=;database=qrcode")
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBoxsp.CheckedChanged
        If TextBoxpassword.UseSystemPasswordChar = True Then

            'show password'
            TextBoxpassword.UseSystemPasswordChar = False

        Else
            'hide password'
            TextBoxpassword.UseSystemPasswordChar = True

        End If
    End Sub

    Private Sub Buttoncancel_Click(sender As Object, e As EventArgs) Handles Buttoncancel.Click
        Me.Close()

    End Sub

    Private Sub Buttonlogin_Click(sender As Object, e As EventArgs) Handles Buttonlogin.Click
        Dim command As New MySqlCommand("SELECT `username`, `password` FROM `login` WHERE `username`=@username AND `password`=@password", connection)

        command.Parameters.Add("@username", MySqlDbType.VarChar).Value = TextBoxusername.Text
        command.Parameters.Add("@password", MySqlDbType.VarChar).Value = TextBoxpassword.Text

        Dim adapter As New MySqlDataAdapter(command)
        Dim table As New DataTable()

        adapter.Fill(table)

        If table.Rows.Count = 0 Then

            MessageBox.Show("Invalid Username Or Password")

        Else

            'MessageBox.Show("Logged In")
            QRCodeForm.Show()
            Me.Hide()


        End If

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub TextBoxusername_TextChanged(sender As Object, e As EventArgs) Handles TextBoxusername.TextChanged

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub TextBoxpassword_TextChanged(sender As Object, e As EventArgs) Handles TextBoxpassword.TextChanged

    End Sub

    Private Sub ButtonSignup_Click(sender As Object, e As EventArgs) Handles ButtonSignup.Click
        Signup.ShowDialog()
    End Sub
End Class
