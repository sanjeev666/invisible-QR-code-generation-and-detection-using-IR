namespace MessagingToolkit.QRCode.Codec
{
    public class QRCodeDecoder
    {
        // Fields
        internal QRCodeSymbol qrCodeSymbol;
        internal int numTryDecode;
        internal ArrayList results;
        internal ArrayList lastResults;
        internal static DebugCanvas canvas;
        internal QRCodeImageReader imageReader;
        internal int numLastCorrections;
        internal bool correctionSucceeded;

	 // Methods
        public QRCodeDecoder();
        internal virtual int[] correctDataBlocks(int[] blocks);
        public virtual string decode(QRCodeImage qrCodeImage);
        internal virtual DecodeResult decode(QRCodeImage qrCodeImage, Point adjust);
        public virtual string decode(QRCodeImage qrCodeImage, Encoding encoding);
        public virtual sbyte[] decodeBytes(QRCodeImage qrCodeImage);
        internal virtual sbyte[] getDecodedByteArray(int[] blocks, int version, int numErrorCorrectionCode);
        internal virtual string getDecodedString(int[] blocks, int version, int numErrorCorrectionCode);
        internal virtual int[][] imageToIntArray(QRCodeImage image);

        // Properties
        public static DebugCanvas Canvas { get; set; }
        internal virtual Point[] AdjustPoints { get; }

        // Nested Types
        internal class DecodeResult
        {
            // Fields
            internal int numCorrections;
            internal bool correctionSucceeded;
            internal sbyte[] decodedBytes;
            private QRCodeDecoder enclosingInstance;

            // Methods
            public DecodeResult(QRCodeDecoder enclosingInstance, sbyte[] decodedBytes, int numErrors, bool correctionSucceeded);
            private void InitBlock(QRCodeDecoder enclosingInstance);

            // Properties
            public virtual sbyte[] DecodedBytes { get; }
            public virtual int NumErrors { get; }
            public virtual bool CorrectionSucceeded { get; }
            public QRCodeDecoder Enclosing_Instance { get; }
        }
    }

    public class QRCodeEncoder
    {
        // Fields
        internal static string DATA_PATH;
        internal static string QRCODE_DATA_PATH;
        internal ERROR_CORRECTION qrcodeErrorCorrect;
        internal ENCODE_MODE qrcodeEncodeMode;
        internal int qrcodeVersion;
        internal int qrcodeStructureappendN;
        internal int qrcodeStructureappendM;
        internal int qrcodeStructureappendParity;
        internal Color qrCodeBackgroundColor;
        internal Color qrCodeForegroundColor;
        internal int qrCodeScale;
        internal string qrcodeStructureappendOriginaldata;

        // Methods
        static QRCodeEncoder();
        public QRCodeEncoder();
        private static sbyte[] calculateByteArrayBits(sbyte[] xa, sbyte[] xb, string ind);
        private static sbyte[] calculateRSECC(sbyte[] codewords, sbyte rsEccCodewords, sbyte[] rsBlockOrder, int maxDataCodewords, int maxCodewords);
        public virtual bool[][] calQrcode(byte[] qrcodeData);
        public virtual int calStructureappendParity(sbyte[] originaldata);
        private static sbyte[] divideDataBy8Bits(int[] data, sbyte[] bits, int maxDataCodewords);
        public virtual Bitmap Encode(string content);
        public virtual Bitmap Encode(string content, Encoding encoding);
        internal static Stream GetEmbeddedFile(string fileName);
        internal static Bitmap GetEmbeddedImage(string fileName);
        internal static XmlDocument GetEmbeddedXml(string fileName);
        private static sbyte selectMask(sbyte[][] matrixContent, int maxCodewordsBitWithRemain);
        public virtual void setStructureappend(int m, int n, int p);

        // Properties
        public virtual ERROR_CORRECTION QRCodeErrorCorrect { get; set; }
        public virtual int QRCodeVersion { get; set; }
        public virtual ENCODE_MODE QRCodeEncodeMode { get; set; }
        public virtual int QRCodeScale { get; set; }
        public virtual Color QRCodeBackgroundColor { get; set; }
        public virtual Color QRCodeForegroundColor { get; set; }

        // Nested Types
        public enum ENCODE_MODE
        {
            ALPHA_NUMERIC,
            NUMERIC,
            BYTE
        }

        public enum ERROR_CORRECTION
        {
            L,
            M,
            Q,
            H
        }
    }
}

 

 
