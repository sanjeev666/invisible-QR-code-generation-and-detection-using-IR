public class QRCodeDecoder
{
    // Fields
    internal QRCodeSymbol qrCodeSymbol;
    internal int numTryDecode = 0;
    internal ArrayList results = ArrayList.Synchronized(new ArrayList(10));
    internal ArrayList lastResults = ArrayList.Synchronized(new ArrayList(10));
    internal static DebugCanvas canvas = new DebugCanvasAdapter();
    internal QRCodeImageReader imageReader;
    internal int numLastCorrections;
    internal bool correctionSucceeded;

    // Methods
    internal virtual int[] correctDataBlocks(int[] blocks)
    {
        ReedSolomon solomon;
        int[] numArray8;
        int num = 0;
        int dataCapacity = this.qrCodeSymbol.DataCapacity;
        int[] numArray = new int[dataCapacity];
        int numRSBlocks = this.qrCodeSymbol.NumRSBlocks;
        int nPAR = this.qrCodeSymbol.NumErrorCollectionCode / numRSBlocks;
        if (numRSBlocks == 1)
        {
            solomon = new ReedSolomon(blocks, nPAR);
            solomon.correct();
            num += solomon.NumCorrectedErrors;
            if (num > 0)
            {
                canvas.println(Convert.ToString(num) + " data errors corrected.");
            }
            else
            {
                canvas.println("No errors found.");
            }
            this.numLastCorrections = num;
            this.correctionSucceeded = solomon.CorrectionSucceeded;
            numArray8 = blocks;
        }
        else
        {
            int num8;
            int num9;
            int num10;
            bool flag;
            int num6 = dataCapacity % numRSBlocks;
            if (num6 == 0)
            {
                int num7 = dataCapacity / numRSBlocks;
                int[][] numArray2 = new int[numRSBlocks][];
                num8 = 0;
                while (true)
                {
                    flag = num8 < numRSBlocks;
                    if (!flag)
                    {
                        int[][] numArray3 = numArray2;
                        num8 = 0;
                        while (true)
                        {
                            if (num8 >= numRSBlocks)
                            {
                                num10 = 0;
                                num8 = 0;
                                while (num8 < numRSBlocks)
                                {
                                    num9 = 0;
                                    while (true)
                                    {
                                        flag = num9 < (num7 - nPAR);
                                        if (!flag)
                                        {
                                            num8++;
                                            break;
                                        }
                                        num10++;
                                        numArray[num10] = numArray3[num8][num9];
                                        num9++;
                                    }
                                }
                                break;
                            }
                            num9 = 0;
                            while (true)
                            {
                                flag = num9 < num7;
                                if (!flag)
                                {
                                    solomon = new ReedSolomon(numArray3[num8], nPAR);
                                    solomon.correct();
                                    num += solomon.NumCorrectedErrors;
                                    this.correctionSucceeded = solomon.CorrectionSucceeded;
                                    num8++;
                                    break;
                                }
                                numArray3[num8][num9] = blocks[(num9 * numRSBlocks) + num8];
                                num9++;
                            }
                        }
                        break;
                    }
                    numArray2[num8] = new int[num7];
                    num8++;
                }
            }
            else
            {
                int num11 = dataCapacity / numRSBlocks;
                int num12 = (dataCapacity / numRSBlocks) + 1;
                int num13 = numRSBlocks - num6;
                int[][] numArray4 = new int[num13][];
                int index = 0;
                while (true)
                {
                    flag = index < num13;
                    if (!flag)
                    {
                        int[][] numArray5 = numArray4;
                        int[][] numArray6 = new int[num6][];
                        int num15 = 0;
                        while (true)
                        {
                            flag = num15 < num6;
                            if (!flag)
                            {
                                int[][] numArray7 = numArray6;
                                num8 = 0;
                                while (true)
                                {
                                    int num16;
                                    if (num8 >= numRSBlocks)
                                    {
                                        num10 = 0;
                                        num8 = 0;
                                        while (num8 < numRSBlocks)
                                        {
                                            if (num8 < num13)
                                            {
                                                num9 = 0;
                                                while (true)
                                                {
                                                    flag = num9 < (num11 - nPAR);
                                                    if (!flag)
                                                    {
                                                        break;
                                                    }
                                                    num10++;
                                                    numArray[num10] = numArray5[num8][num9];
                                                    num9++;
                                                }
                                            }
                                            else
                                            {
                                                num9 = 0;
                                                while (true)
                                                {
                                                    flag = num9 < (num12 - nPAR);
                                                    if (!flag)
                                                    {
                                                        break;
                                                    }
                                                    num10++;
                                                    numArray[num10] = numArray7[num8 - num13][num9];
                                                    num9++;
                                                }
                                            }
                                            num8++;
                                        }
                                        break;
                                    }
                                    if (num8 < num13)
                                    {
                                        num16 = 0;
                                        num9 = 0;
                                        while (true)
                                        {
                                            flag = num9 < num11;
                                            if (!flag)
                                            {
                                                solomon = new ReedSolomon(numArray5[num8], nPAR);
                                                solomon.correct();
                                                num += solomon.NumCorrectedErrors;
                                                this.correctionSucceeded = solomon.CorrectionSucceeded;
                                                break;
                                            }
                                            if (num9 == (num11 - nPAR))
                                            {
                                                num16 = num6;
                                            }
                                            numArray5[num8][num9] = blocks[((num9 * numRSBlocks) + num8) + num16];
                                            num9++;
                                        }
                                    }
                                    else
                                    {
                                        num16 = 0;
                                        num9 = 0;
                                        while (true)
                                        {
                                            flag = num9 < num12;
                                            if (!flag)
                                            {
                                                solomon = new ReedSolomon(numArray7[num8 - num13], nPAR);
                                                solomon.correct();
                                                num += solomon.NumCorrectedErrors;
                                                this.correctionSucceeded = solomon.CorrectionSucceeded;
                                                break;
                                            }
                                            if (num9 == (num11 - nPAR))
                                            {
                                                num16 = num13;
                                            }
                                            numArray7[num8 - num13][num9] = blocks[((num9 * numRSBlocks) + num8) - num16];
                                            num9++;
                                        }
                                    }
                                    num8++;
                                }
                                break;
                            }
                            numArray6[num15] = new int[num12];
                            num15++;
                        }
                        break;
                    }
                    numArray4[index] = new int[num11];
                    index++;
                }
            }
            if (num > 0)
            {
                canvas.println(Convert.ToString(num) + " data errors corrected.");
            }
            else
            {
                canvas.println("No errors found.");
            }
            this.numLastCorrections = num;
            numArray8 = numArray;
        }
        return numArray8;
    }

    public virtual string decode(QRCodeImage qrCodeImage)
    {
        sbyte[] src = this.decodeBytes(qrCodeImage);
        byte[] dst = new byte[src.Length];
        Buffer.BlockCopy(src, 0, dst, 0, dst.Length);
        Encoding encoding = !QRCodeUtility.IsUnicode(dst) ? Encoding.ASCII : Encoding.Unicode;
        return encoding.GetString(dst);
    }

    internal virtual DecodeResult decode(QRCodeImage qrCodeImage, Point adjust)
    {
        DecodeResult result;
        try
        {
            if (this.numTryDecode != 0)
            {
                canvas.println("--");
                canvas.println("Decoding restarted #" + this.numTryDecode);
                this.qrCodeSymbol = this.imageReader.getQRCodeSymbolWithAdjustedGrid(adjust);
            }
            else
            {
                canvas.println("Decoding started");
                int[][] image = this.imageToIntArray(qrCodeImage);
                this.imageReader = new QRCodeImageReader();
                this.qrCodeSymbol = this.imageReader.getQRCodeSymbol(image);
            }
        }
        catch (SymbolNotFoundException exception1)
        {
            throw new DecodingFailedException(exception1.Message);
        }
        canvas.println("Created QRCode symbol.");
        canvas.println("Reading symbol.");
        canvas.println("Version: " + this.qrCodeSymbol.VersionReference);
        canvas.println("Mask pattern: " + this.qrCodeSymbol.MaskPatternRefererAsString);
        int[] blocks = this.qrCodeSymbol.Blocks;
        canvas.println("Correcting data errors.");
        blocks = this.correctDataBlocks(blocks);
        try
        {
            sbyte[] decodedBytes = this.getDecodedByteArray(blocks, this.qrCodeSymbol.Version, this.qrCodeSymbol.NumErrorCollectionCode);
            result = new DecodeResult(this, decodedBytes, this.numLastCorrections, this.correctionSucceeded);
        }
        catch (InvalidDataBlockException exception2)
        {
            canvas.println(exception2.Message);
            throw new DecodingFailedException(exception2.Message);
        }
        return result;
    }

    public virtual string decode(QRCodeImage qrCodeImage, Encoding encoding)
    {
        sbyte[] src = this.decodeBytes(qrCodeImage);
        byte[] dst = new byte[src.Length];
        Buffer.BlockCopy(src, 0, dst, 0, dst.Length);
        return encoding.GetString(dst);
    }

    public virtual sbyte[] decodeBytes(QRCodeImage qrCodeImage)
    {
        Point[] adjustPoints = this.AdjustPoints;
        ArrayList list = ArrayList.Synchronized(new ArrayList(10));
        while (true)
        {
            DecodeResult result;
            sbyte[] decodedBytes;
            bool flag = this.numTryDecode < adjustPoints.Length;
            if (flag)
            {
                try
                {
                    result = this.decode(qrCodeImage, adjustPoints[this.numTryDecode]);
                    flag = !result.CorrectionSucceeded;
                    if (flag)
                    {
                        list.Add(result);
                        canvas.println("Decoding succeeded but could not correct");
                        canvas.println("all errors. Retrying..");
                        continue;
                    }
                    decodedBytes = result.DecodedBytes;
                }
                catch (DecodingFailedException exception)
                {
                    if (exception.Message.IndexOf("Finder Pattern") >= 0)
                    {
                        throw exception;
                    }
                    continue;
                }
                finally
                {
                    this.numTryDecode++;
                    continue;
                }
            }
            else
            {
                if (list.Count == 0)
                {
                    throw new DecodingFailedException("Give up decoding");
                }
                int num = -1;
                int numErrors = 0x7fff_ffff;
                int num3 = 0;
                while (true)
                {
                    flag = num3 < list.Count;
                    if (!flag)
                    {
                        canvas.println("All trials need for correct error");
                        canvas.println("Reporting #" + num + " that,");
                        canvas.println("corrected minimum errors (" + numErrors + ")");
                        canvas.println("Decoding finished.");
                        decodedBytes = ((DecodeResult) list[num]).DecodedBytes;
                        break;
                    }
                    result = (DecodeResult) list[num3];
                    if (result.NumErrors < numErrors)
                    {
                        numErrors = result.NumErrors;
                        num = num3;
                    }
                    num3++;
                }
            }
            return decodedBytes;
        }
    }

    internal virtual sbyte[] getDecodedByteArray(int[] blocks, int version, int numErrorCorrectionCode)
    {
        sbyte[] dataByte;
        QRCodeDataBlockReader reader = new QRCodeDataBlockReader(blocks, version, numErrorCorrectionCode);
        try
        {
            dataByte = reader.DataByte;
        }
        catch (InvalidDataBlockException exception1)
        {
            throw exception1;
        }
        return dataByte;
    }

    internal virtual string getDecodedString(int[] blocks, int version, int numErrorCorrectionCode)
    {
        string dataString = null;
        QRCodeDataBlockReader reader = new QRCodeDataBlockReader(blocks, version, numErrorCorrectionCode);
        try
        {
            dataString = reader.DataString;
        }
        catch (IndexOutOfRangeException exception1)
        {
            throw new InvalidDataBlockException(exception1.Message);
        }
        return dataString;
    }

    internal virtual int[][] imageToIntArray(QRCodeImage image)
    {
        int width = image.Width;
        int height = image.Height;
        int[][] numArray = new int[width][];
        int index = 0;
        while (true)
        {
            bool flag = index < width;
            if (!flag)
            {
                int num4 = 0;
                while (num4 < height)
                {
                    int num5 = 0;
                    while (true)
                    {
                        flag = num5 < width;
                        if (!flag)
                        {
                            num4++;
                            break;
                        }
                        numArray[num5][num4] = image.getPixel(num5, num4);
                        num5++;
                    }
                }
                return numArray;
            }
            numArray[index] = new int[height];
            index++;
        }
    }

    // Properties
    public static DebugCanvas Canvas
    {
        get => 
            canvas;
        set => 
            (canvas = value);
    }

    internal virtual Point[] AdjustPoints
    {
        get
        {
            ArrayList list = ArrayList.Synchronized(new ArrayList(10));
            int num = 0;
            while (true)
            {
                bool flag = num < 4;
                if (!flag)
                {
                    int num2 = 0;
                    int num3 = 0;
                    int num4 = 0;
                    while (num4 > -4)
                    {
                        int num5 = 0;
                        while (true)
                        {
                            flag = num5 > -4;
                            if (!flag)
                            {
                                num4--;
                                break;
                            }
                            if ((num5 != num4) && (((num5 + num4) % 2) == 0))
                            {
                                list.Add(new Point(num5 - num2, num4 - num3));
                                num2 = num5;
                                num3 = num4;
                            }
                            num5--;
                        }
                    }
                    Point[] pointArray = new Point[list.Count];
                    int index = 0;
                    while (true)
                    {
                        flag = index < pointArray.Length;
                        if (!flag)
                        {
                            return pointArray;
                        }
                        pointArray[index] = (Point) list[index];
                        index++;
                    }
                }
                list.Add(new Point(1, 1));
                num++;
            }
        }
    }

    // Nested Types
    internal class DecodeResult
    {
        // Fields
        internal int numCorrections;
        internal bool correctionSucceeded;
        internal sbyte[] decodedBytes;
        private QRCodeDecoder enclosingInstance;

        // Methods
        public DecodeResult(QRCodeDecoder enclosingInstance, sbyte[] decodedBytes, int numErrors, bool correctionSucceeded)
        {
            this.InitBlock(enclosingInstance);
            this.decodedBytes = decodedBytes;
            this.numCorrections = numErrors;
            this.correctionSucceeded = correctionSucceeded;
        }

        private void InitBlock(QRCodeDecoder enclosingInstance)
        {
            this.enclosingInstance = enclosingInstance;
        }

        // Properties
        public virtual sbyte[] DecodedBytes =>
            this.decodedBytes;

        public virtual int NumErrors =>
            this.numCorrections;

        public virtual bool CorrectionSucceeded =>
            this.correctionSucceeded;

        public QRCodeDecoder Enclosing_Instance =>
            this.enclosingInstance;
    }
}

 

 
